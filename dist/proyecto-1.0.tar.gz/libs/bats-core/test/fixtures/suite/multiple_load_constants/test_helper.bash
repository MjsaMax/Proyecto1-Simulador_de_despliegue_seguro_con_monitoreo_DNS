# shellcheck disable=SC2034
readonly A_CONSTANT="value"
