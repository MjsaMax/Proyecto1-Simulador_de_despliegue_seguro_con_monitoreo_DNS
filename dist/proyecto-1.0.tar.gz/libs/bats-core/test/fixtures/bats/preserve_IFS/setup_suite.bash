load helper.bash

check_ifs

teardown_suite() {
    check_ifs
}

setup_suite() {
    check_ifs
}