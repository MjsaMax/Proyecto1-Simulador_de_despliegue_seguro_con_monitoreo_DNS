bats::on_failure() {
    echo "failure callback"
}

setup_suite() {
    false
}