#!/usr/bin/env bash
cat >/dev/null # eat up all input
sleep 1
echo "Finished" # mark finish