setup_suite() {
  echo "setup_suite before" >&2
  false
  echo "setup_suite after" >&2
}

teardown_suite() {
  echo "teardown_suite" >&2
}
