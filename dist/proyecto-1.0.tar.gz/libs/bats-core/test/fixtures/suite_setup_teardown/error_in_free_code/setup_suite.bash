call-to-undefined-command

setup_suite() {
  :
}
